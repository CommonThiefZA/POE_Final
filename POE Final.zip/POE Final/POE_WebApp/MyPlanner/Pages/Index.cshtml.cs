﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;
using static System.Net.Mime.MediaTypeNames;

namespace MyPlanner.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        public string message { get; set; }

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {
            message = "";
        }

        public void OnPost(string button)
        {
            string stdNumber = Request.Form["stdNumber"];
            string password = Request.Form["password"];
            string hash = HashPassword(password);

            if(button == "register")
            {
                string connectionString;
                SqlConnection cnn;

                connectionString = @"Data Source=ROSS-GAMINGPC;Initial Catalog=STUDY_PLANNER;Integrated Security=True";
                cnn = new SqlConnection(connectionString);
                cnn.Open();

                SqlCommand command;
                SqlDataAdapter dataAdapter = new SqlDataAdapter();
                string sql = "";

                sql = $"INSERT INTO dbo.student VALUES ('{stdNumber}','{hash}')";

                command = new SqlCommand(sql, cnn);

                dataAdapter.InsertCommand = new SqlCommand(sql, cnn);
                dataAdapter.InsertCommand.ExecuteNonQuery();

                command.Dispose();
                cnn.Close();

                message = "Registered Successfully. Please Enter Details again to Log In.";

            } else if (button == "login")
            {
                string connectionString;
                SqlConnection cnn;

                connectionString = @"Data Source=ROSS-GAMINGPC;Initial Catalog=STUDY_PLANNER;Integrated Security=True";
                cnn = new SqlConnection(connectionString);
                cnn.Open();

                SqlCommand command;
                SqlDataReader dataReader;
                string sql, output = "";

                sql = $"SELECT password FROM dbo.student WHERE stdNumber = '{stdNumber}'";

                command = new SqlCommand(sql, cnn);

                dataReader = command.ExecuteReader();

                while (dataReader.Read())
                {
                    output = output + dataReader.GetString(0);
                }

                if (output.Equals(hash))
                {
                    message = "Logged In";
                    Response.Redirect($"Planner?Parameter={stdNumber}");
                }
                else
                {
                    message = "Failed to Log In";
                }

                dataReader.Close();
                command.Dispose();
                cnn.Close();
            }            
        }

        public static string HashPassword(string password)
        {
            var sha = SHA256.Create();
            var asByteArray = Encoding.Default.GetBytes(password);

            var hashPassword = sha.ComputeHash(asByteArray);

            return Convert.ToBase64String(hashPassword);
        }
    }
}