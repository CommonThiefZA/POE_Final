using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using MyPlannerApp;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections;

namespace MyPlanner.Pages
{
    public class PlannerModel : PageModel
    {        
        Module moduleClass = new Module();
        Hours hoursClass = new Hours();

        public List<ModuleInfo> moduleInfos = new List<ModuleInfo>();
        public List<HoursInfo> hourInfos = new List<HoursInfo>();
        public List<PopulateDropList> dropListInfos = new List<PopulateDropList>();

        public void OnGet()
        {
            StudentNumber num = new StudentNumber();
            num.studentNumber = Request.Query["Parameter"];
            string studentNumber = num.studentNumber;

            FillModuleDataTables(studentNumber, moduleInfos);
            FillHoursDataTables(studentNumber, hourInfos);
            PopulateDropListBox(studentNumber, dropListInfos);
        }

        public void PopulateDropListBox(string student, List<PopulateDropList> dropListInfos)
        {
            string connectionString;
            SqlConnection cnn;

            connectionString = @"Data Source=ROSS-GAMINGPC;Initial Catalog=STUDY_PLANNER;Integrated Security=True";
            cnn = new SqlConnection(connectionString);
            cnn.Open();

            string sql = $"SELECT module_code FROM dbo.module WHERE (stdNumber = '{student}')";

            using (SqlCommand cmd = new SqlCommand(sql, cnn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        PopulateDropList info = new PopulateDropList();
                        info.module_Code = reader.GetString(0);

                        dropListInfos.Add(info);
                    }
                }
            }

            cnn.Close();
        }

        public void FillHoursDataTables(string student, List<HoursInfo> hourInfos)
        {
            string connectionString;
            SqlConnection cnn;

            connectionString = @"Data Source=ROSS-GAMINGPC;Initial Catalog=STUDY_PLANNER;Integrated Security=True";
            cnn = new SqlConnection(connectionString);
            cnn.Open();

            string sql = $"SELECT * FROM dbo.hours WHERE (stdNumber = '{student}')";

            using (SqlCommand cmd = new SqlCommand(sql, cnn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        HoursInfo info = new HoursInfo();
                        info.stdNumber = reader.GetString(0);
                        info.module_code = reader.GetString(1);
                        info.self_study = reader.GetInt32(2);
                        info.hours_remain = reader.GetInt32(3);

                        hourInfos.Add(info);
                    }
                }
            }

            cnn.Close();
        }

        public static void FillModuleDataTables(string student, List<ModuleInfo> moduleInfos)
        {
            string connectionString;
            SqlConnection cnn;

            connectionString = @"Data Source=ROSS-GAMINGPC;Initial Catalog=STUDY_PLANNER;Integrated Security=True";
            cnn = new SqlConnection(connectionString);
            cnn.Open();

            string sql = $"SELECT * FROM dbo.module WHERE (stdNumber = '{student}')";

            using (SqlCommand cmd = new SqlCommand(sql, cnn))
            {
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        ModuleInfo info = new ModuleInfo();
                        info.stdNumber = reader.GetString(0);
                        info.module_code = reader.GetString(1);
                        info.module_name = reader.GetString(2);
                        info.credits = reader.GetInt32(3);
                        info.class_hours = reader.GetInt32(4);
                        info.semester_weeks = reader.GetInt32(5);

                        moduleInfos.Add(info);
                    }
                }
            }
            
            cnn.Close();
        }

        public void OnPost(string button)
        {
            StudentNumber num = new StudentNumber();
            num.studentNumber = Request.Query["Parameter"];
            string studentNumber = num.studentNumber;
            DateTime dt = new DateTime();
            //connect to database

            string connectionString;
            SqlConnection cnn;         

            connectionString = @"Data Source=ROSS-GAMINGPC;Initial Catalog=STUDY_PLANNER;Integrated Security=True";
            cnn = new SqlConnection(connectionString);
            cnn.Open();

            //add module to database

            if (button == "moduleSubmit")
            {
                string code = Request.Form["moduleCode"];
                string moduleName = Request.Form["moduleName"];
                int credits = Convert.ToInt32(Request.Form["moduleCredits"]);
                int hours = Convert.ToInt32(Request.Form["classHours"]);
                int weeks = Convert.ToInt32(Request.Form["semesterWeeks"]);
                string startDate;
                double selfStudy = 0;

                dt = Convert.ToDateTime(Request.Form["startDate"]);
                startDate = dt.ToString("dd/mm/yyyy");

                //add to module class

                moduleClass.ModuleCode = code;
                moduleClass.ModuleName = moduleName;
                moduleClass.Credits = credits;
                moduleClass.WeekHours = hours;
                moduleClass.SemesterWeeks = weeks;
                moduleClass.StartDate = startDate;

                moduleClass.AddModule();

                selfStudy = moduleClass.CalcSelfStudyHours();

                AddModule(cnn,studentNumber,code,moduleName,credits,hours,weeks,startDate);
                AddHours(cnn,selfStudy,studentNumber,code);

            }else if (button == "hoursSubmit")
            {
                PopulateDropList dropList = new PopulateDropList();

                int hoursWorked = Convert.ToInt32(Request.Form["hoursWorked"]);
                string moduleWorked = Request.Form["module_code"];
                Console.WriteLine(moduleWorked);
                dt = Convert.ToDateTime(Request.Form["workDate"]);
                string workDate = dt.ToString("dd/mm/yyyy");

                //add to hours class

                hoursClass.HoursWorked = hoursWorked;
                hoursClass.Date = workDate;
                hoursClass.AddDate();

                SubmitHours(cnn,hoursWorked,moduleWorked,workDate,studentNumber);
            }
            cnn.Close();            
        }

        public void SubmitHours(SqlConnection cnn, int hoursWorked, string moduleWorked, string workDate, string studentNumber)
        {
            //add hours worked to the database 

            //get self study from database

            int selfStudy = 0;
            SqlCommand command2;
            SqlDataReader dataReader;
            string sql2, output = "";

            sql2 = $"SELECT self_study FROM dbo.hours WHERE (stdNumber = '{studentNumber}') AND module_code = '{moduleWorked}'";

            command2 = new SqlCommand(sql2, cnn);

            dataReader = command2.ExecuteReader();

            while (dataReader.Read())
            {
                output = output + dataReader.GetInt32(0);
            }

            selfStudy = Convert.ToInt32(output);

            dataReader.Close();
            command2.Dispose();


            //get current hours remaining from database

            int oldRemain = 0;
            SqlCommand remainCmd;
            SqlDataReader remainData;
            string remainSql, remainOutput = "";

            remainSql = $"SELECT hours_remain FROM dbo.hours WHERE (stdNumber = '{studentNumber}') AND (module_code = '{moduleWorked}')";

            remainCmd = new SqlCommand(remainSql, cnn);

            remainData = remainCmd.ExecuteReader();

            while (remainData.Read())
            {
                remainOutput = remainOutput + remainData.GetInt32(0);
            }

            oldRemain = Convert.ToInt32(remainOutput);

            remainData.Close();
            remainCmd.Dispose();

            //Update database

            int newHours = selfStudy + hoursWorked;
            int newRemaining = oldRemain - hoursWorked;

            SqlCommand updateCmd;
            SqlDataAdapter updateAdapter = new SqlDataAdapter();
            string updateSql = "";

            updateSql = $"UPDATE dbo.hours SET self_study = {newHours}, hours_remain = {newRemaining} WHERE stdNumber = '{studentNumber}' AND module_code = '{moduleWorked}'";

            updateCmd = new SqlCommand(updateSql, cnn);
            updateAdapter.UpdateCommand = new SqlCommand(updateSql, cnn);
            updateAdapter.UpdateCommand.ExecuteNonQuery();

            updateCmd.Dispose();

            //update tables and list box
            FillHoursDataTables(studentNumber, hourInfos);
            FillModuleDataTables(studentNumber, moduleInfos);
            PopulateDropListBox(studentNumber, dropListInfos);

        }

        public void AddHours(SqlConnection cnn, double selfStudy, string studentNumber, string code)
        {
            //add hours to database

            SqlCommand command2;
            SqlDataAdapter dataAdapter2 = new SqlDataAdapter();
            string sql2 = "";

            int remainingHours = Convert.ToInt32(selfStudy);

            sql2 = $"INSERT INTO dbo.hours VALUES ('{studentNumber}','{code}',{0},{remainingHours})";

            command2 = new SqlCommand(sql2, cnn);

            dataAdapter2.InsertCommand = new SqlCommand(sql2, cnn);
            dataAdapter2.InsertCommand.ExecuteNonQuery();

            command2.Dispose();

            //update tables and list box
            FillHoursDataTables(studentNumber, hourInfos);
            FillModuleDataTables(studentNumber, moduleInfos);
            PopulateDropListBox(studentNumber, dropListInfos);
        }

        public void AddModule(SqlConnection cnn,string studentNumber, string code, string moduleName, int credits, int hours, int weeks, string startDate)
        {
            SqlCommand command;
            SqlDataAdapter dataAdapter = new SqlDataAdapter();
            string sql = "";

            sql = $"INSERT INTO dbo.module VALUES ('{studentNumber}','{code}','{moduleName}',{credits},{hours},{weeks})";

            command = new SqlCommand(sql, cnn);

            dataAdapter.InsertCommand = new SqlCommand(sql, cnn);
            dataAdapter.InsertCommand.ExecuteNonQuery();

            command.Dispose();
        }

        public class StudentNumber
        {
            public string studentNumber { get; set; }            
        }
    }

    public class ModuleInfo
    {
        public string stdNumber { get; set; }
        public string module_code { get; set; }
        public string module_name { get; set; }
        public int credits { get; set; }
        public int class_hours { get; set; }
        public int semester_weeks { get; set; }
    }

    public class HoursInfo
    {
        public string stdNumber { get; set; }
        public string module_code { get; set; }
        public int self_study { get; set; }
        public int hours_remain { get; set; }
    }

    public class PopulateDropList
    {
        public string module_Code { get; set; }
    }

}
