﻿namespace MyPlannerApp
{
    public class Hours
    {
        private List<Hours> hoursList = new List<Hours>();

        private int hoursWorked;
        private string date;

        public Hours()
        {
            hoursWorked = 0;
            date = "";
        }

        public Hours(int hoursWorked, string date)
        {
            this.hoursWorked = hoursWorked;
            this.date = date;
        }

        public int HoursWorked
        {
            get { return hoursWorked; }
            set { hoursWorked = value; }
        }

        public string Date
        {
            get { return date; }
            set { date = value; }
        }

        public List<Hours> ListHours
        {
            get { return hoursList; }
            set { hoursList = value; }
        }

        public void AddDate()
        {
            int hours = HoursWorked;
            string date1 = Date;

            hoursList.Add(new Hours(hours, date1));
        }
    }
}