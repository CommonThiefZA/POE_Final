﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPlannerApp
{
    public class Module
    {
        private List<Module> moduleList = new List<Module>();

        private string moduleCode;
        private string moduleName;
        private int credits;
        private int weekHours;
        private int semesterWeeks;
        private string startDate;
        private double selfStudyHours;

        public Module()
        {
            moduleCode = "";
            moduleName = "";
            credits = 0;
            weekHours = 0;
            semesterWeeks = 0;
            startDate = "";
            selfStudyHours = 0;
        }

        public Module(string moduleCode, string moduleName, int credits, int weekHours, int semesterWeeks, string startDate, double selfStudyHours)
        {
            this.moduleCode = moduleCode;
            this.moduleName = moduleName;
            this.credits = credits;
            this.weekHours = weekHours;
            this.semesterWeeks = semesterWeeks;
            this.startDate = startDate;
            this.selfStudyHours = selfStudyHours;
        }

        public string ModuleCode
        {
            get { return moduleCode; }
            set { moduleCode = value; }
        }

        public string ModuleName
        {
            get { return moduleName; }
            set { moduleName = value; }
        }

        public int Credits
        {
            get { return credits; }
            set { credits = value; }
        }

        public int WeekHours
        {
            get { return weekHours; }
            set { weekHours = value; }

        }

        public string StartDate
        {
            get { return startDate; }
            set { startDate = value; }
        }

        public int SemesterWeeks
        {
            get { return semesterWeeks; }
            set { semesterWeeks = value; }
        }

        public double SelfStudyHours
        {
            get { return selfStudyHours; }
            set { selfStudyHours = value; }
        }

        public double CalcSelfStudyHours()
        {
            double study;
            study = (((Credits * 10) / SemesterWeeks) - WeekHours);

            return study;
        }

        public List<Module> ListModules
        {
            get { return moduleList; }
            set { moduleList = value; }
        }

        public void AddModule()
        {
            string code = ModuleCode;
            string name = ModuleName;
            int credits = Credits;
            int hours = WeekHours;
            int weeks = SemesterWeeks;
            string date = StartDate;
            double selfStudy = SelfStudyHours;

            moduleList.Add(new Module(code, name, credits, hours, weeks, date, selfStudy));
        }

    }
}
